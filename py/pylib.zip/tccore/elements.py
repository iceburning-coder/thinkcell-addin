"""Stable element identity shared with the Office add-in state model."""

from __future__ import annotations

import hashlib
import json
from typing import Optional


_TYPE_PREFIX = {
    "data-label": "label",
    "legend": "legend",
    "cagr-arrow": "cagr",
}


def _validate_paired_unicode(value: str, field: str) -> str:
    index = 0
    while index < len(value):
        point = ord(value[index])
        if 0xD800 <= point <= 0xDBFF:
            if index + 1 >= len(value) or not 0xDC00 <= ord(value[index + 1]) <= 0xDFFF:
                raise ValueError(f"{field} contains an unpaired Unicode surrogate")
            index += 2
            continue
        if 0xDC00 <= point <= 0xDFFF:
            raise ValueError(f"{field} contains an unpaired Unicode surrogate")
        index += 1
    return value


def _required_string(value: object, field: str) -> str:
    if not isinstance(value, str) or not value:
        raise ValueError(f"{field} must be a non-empty string")
    return _validate_paired_unicode(value, field)


def _nullable_string(value: object, field: str) -> Optional[str]:
    if value is None:
        return None
    if not isinstance(value, str) or not value:
        raise ValueError(f"{field} must be null or a non-empty string")
    return _validate_paired_unicode(value, field)


def stable_element_id(
    *,
    chart_id: str,
    element_type: str,
    semantic_role: str,
    row_key: Optional[str] = None,
    series_key: Optional[str] = None,
    parent_element_id: Optional[str] = None,
    display_name: object = None,
    row_index: object = None,
) -> str:
    """Return a stable v4 element ID from semantic identity only.

    ``display_name`` and ``row_index`` are deliberately ignored so renaming
    or reordering cannot change identity. Unknown keyword inputs are rejected.
    """

    del display_name, row_index

    chart_id = _required_string(chart_id, "chart_id")
    element_type = _required_string(element_type, "element_type")
    if element_type not in _TYPE_PREFIX:
        raise ValueError("element_type is not supported")
    canonical = [
        chart_id,
        element_type,
        _required_string(semantic_role, "semantic_role"),
        _nullable_string(row_key, "row_key"),
        _nullable_string(series_key, "series_key"),
        _nullable_string(parent_element_id, "parent_element_id"),
    ]
    payload = json.dumps(canonical, ensure_ascii=False, separators=(",", ":")).encode("utf-8")
    digest = hashlib.sha256(payload).hexdigest()[:16]
    return f"tc4:{_TYPE_PREFIX[element_type]}:{digest}"
