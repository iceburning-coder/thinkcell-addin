"""甘特 / 时间线：日历刻度（年/季/月/周，周起始日，yy/yyyy）、活动条、里程碑、括号、
底纹（假期）、行底纹/分隔线、三列标签（活动/负责人/备注，可放 Harvey ball / 复选框）、今天线、流程箭头。"""
from __future__ import annotations

from .axes import DateAxis, as_date
from .canvas import text_w
from .charts_bar import Ctx
from .style import series_colors as _auto_colors
from . import legend as LG
from .table import harvey, checkbox


def gantt(fig, rows, d0, d1, scale="month", sub_scale=None, week_start=0, year_fmt="yyyy", today=None,
          milestones=None, brackets=None, shades=None, cols=("负责人", "备注"), group_colors=None,
          row_shading=True, flow=None, label_col_w=None, legend="none", legend_reverse=False,
          series_colors=None):
    """
    rows: [dict(name, start, end, owner=, remark=, group=, milestone=date, status=0-4|'check'|'cross',
                indent=0, bold=False)]
      end 省略 + milestone：该行只画里程碑菱形
    milestones: [dict(name, date, line=True)]  跨所有行的里程碑（带竖线）
    brackets:   [dict(start, end, text, row=None)] 顶部时间段括号（row 指定则画在该行上方）
    shades:     [dict(start, end, text=)]      底纹区（假期/冻结期）
    flow:       [(行 a, 行 b)]                  流程箭头：a 结束 → b 开始
    cols:       右侧标签列标题；status 列显示为 Harvey ball（0-4）或复选框
    """
    t, c = fig.t, fig.c
    _grp = []
    for r in rows:
        if r.get("group") is not None and r.get("group") not in _grp:
            _grp.append(r.get("group"))
    lg = LG.norm(legend, "none") if len(_grp) > 1 else "none"
    if lg == "label":
        lg = "top"
    spot = LG.reserve(fig, lg, [str(g) for g in _grp])
    x0, y0, w, h = fig.box
    n = len(rows)
    lab_w = label_col_w or max(text_w(r["name"], t["SIZE_LABEL"]) + r.get("indent", 0) * 10 for r in rows) + 14
    col_ws = []
    for ci, cn in enumerate(cols or []):
        key = ["owner", "remark"][ci] if ci < 2 else None
        vals = [str(r.get(key, "")) for r in rows] if key else []
        col_ws.append(max([text_w(cn, t["SIZE_SMALL"])] + [text_w(v, t["SIZE_SMALL"] + 0.5) for v in vals]) + 14)
    has_status = any("status" in r for r in rows)
    st_w = 26 if has_status else 0
    left = x0 + lab_w
    right = x0 + w - sum(col_ws) - st_w
    head = t["SIZE_LABEL"] * (3.4 if sub_scale else 2.2) + (16 if brackets else 0)
    top = y0 + head
    bottom = y0 + h - 4
    rh = (bottom - top) / max(n, 1)
    dax = DateAxis(d0, d1, left, right)
    gcol = {}
    groups = []
    for r in rows:
        if r.get("group") not in groups:
            groups.append(r.get("group"))
    pal = group_colors or _auto_colors(t, max(len(groups), 1))
    for g, col in zip(groups, pal):
        gcol[g] = (series_colors or {}).get(str(g)) or col
    # 行底纹
    for i in range(n):
        if row_shading and i % 2 == 0:
            c.rect(x0, top + i * rh, w, rh, fill=t["SHADE"])
    # 底纹区
    for s in shades or []:
        xa, xb = dax.pos(s["start"]), dax.pos(s["end"])
        c.rect(xa, top, xb - xa, bottom - top, fill="#E9E9E9", opacity=0.7)
        if s.get("text"):
            c.text((xa + xb) / 2, bottom - 3, s["text"], t["SIZE_SMALL"] - 0.5, t["FG_MUTED"], "middle", "bottom")
    # 日历刻度：主刻度实线 + 标签，次刻度虚线
    ticks = dax.ticks(scale, week_start, year_fmt)
    ytick = top - t["SIZE_LABEL"] * (2.1 if sub_scale else 0.9)
    for j, (d, lab, major) in enumerate(ticks):
        x = dax.pos(d)
        if x >= right - 1:          # 落在日期范围末端的刻度：只画线，不写标签（避免压到右侧标签列）
            continue
        c.line(x, top, x, bottom, "#D0D0D0" if major else "#E4E4E4", 0.6, None if major else "2 2")
        nxt = min(dax.pos(ticks[j + 1][0]), right) if j + 1 < len(ticks) else right
        lab_w = text_w(lab, t["SIZE_SMALL"] + 0.5)
        if nxt - x < lab_w * 0.8:   # 最后一段太窄放不下标签
            continue
        c.text((x + nxt) / 2, ytick, lab, t["SIZE_SMALL"] + 0.5, t["FG"], "middle", "middle", bold=major and scale != "year")
    if sub_scale:
        for d, lab, major in dax.ticks(sub_scale, week_start, year_fmt):
            x = dax.pos(d)
            c.line(x, top - 6, x, top, "#BDBDBD", 0.5)
            c.text(x + 2, top - t["SIZE_LABEL"] * 0.8, lab, t["SIZE_SMALL"] - 1, t["FG_MUTED"], "start", "middle")
    c.line(x0, top, x0 + w, top, t["AXIS"], 0.8)
    # 列标题
    xc = right
    for cn, cw in zip(cols or [], col_ws):
        c.text(xc + 8, top - 4, cn, t["SIZE_SMALL"], t["FG_MUTED"], "start", "bottom", bold=True)
        xc += cw
    # 行
    geo = {}
    for i, r in enumerate(rows):
        yc = top + (i + 0.5) * rh
        c.text(x0 + 2 + r.get("indent", 0) * 10, yc, r["name"], t["SIZE_LABEL"], t["FG"], "start", "middle",
               bold=r.get("bold", False))
        col = r.get("color") or gcol.get(r.get("group"))
        if r.get("start") and r.get("end"):
            xa, xb = dax.pos(r["start"]), dax.pos(r["end"])
            bh = min(rh * 0.5, 14)
            c.rect(xa, yc - bh / 2, max(xb - xa, 1.5), bh, fill=col)
            geo[i] = (xa, xb, yc)
        if r.get("milestone"):
            xm = dax.pos(r["milestone"])
            s = min(rh * 0.28, 6)
            c.poly([(xm, yc - s), (xm + s, yc), (xm, yc + s), (xm - s, yc)], fill=t["FG"])
            geo.setdefault(i, (xm, xm, yc))
        xc = right
        for ci, (cn, cw) in enumerate(zip(cols or [], col_ws)):
            key = ["owner", "remark"][ci] if ci < 2 else None
            if key and r.get(key):
                c.text(xc + 8, yc, str(r[key]), t["SIZE_SMALL"] + 0.5, t["FG_MUTED"], "start", "middle")
            xc += cw
        if "status" in r:
            stv = r["status"]
            if isinstance(stv, str):
                checkbox(c, t, xc + 10, yc, 10, stv)
            else:
                harvey(c, t, xc + 12, yc, 5.5, stv)
    # 流程箭头
    for a, b in flow or []:
        if a in geo and b in geo:
            xa, _, ya = geo[a][0], geo[a][1], geo[a][2]
            xe = geo[a][1]
            xs, yb = geo[b][0], geo[b][2]
            c.polyline_arrow([(xe, ya), (xe + 4, ya), (xe + 4, yb), (xs, yb)], t["FG_MUTED"], 0.7, 4)
    # 跨行里程碑
    for m in milestones or []:
        xm = dax.pos(m["date"])
        if m.get("line", True):
            c.line(xm, top, xm, bottom, t["FG"], 0.6, "3 2")
        s = 5
        c.poly([(xm, top + 1), (xm + s, top + 1 + s), (xm, top + 1 + 2 * s), (xm - s, top + 1 + s)], fill=t["FG"])
        c.text(xm - s - 2, top + 1 + s, m["name"], t["SIZE_SMALL"], t["FG"], "end", "middle", bold=True)
    # 括号
    for bk in brackets or []:
        xa, xb = dax.pos(bk["start"]), dax.pos(bk["end"])
        yb = (top + bk["row"] * rh + 3) if bk.get("row") is not None else y0 + 8
        c.poly([(xa, yb + 5), (xa, yb), (xb, yb), (xb, yb + 5)], stroke=t["FG_MUTED"], sw=0.8, closed=False)
        c.text((xa + xb) / 2, yb - 1, bk["text"], t["SIZE_SMALL"], t["FG_MUTED"], "middle", "bottom")
    if today:
        xt = dax.pos(today)
        c.line(xt, top - 4, xt, bottom, t["ACCENT"], 1.1)
        c.text(xt, bottom + 1, "今天", t["SIZE_SMALL"] - 0.5, t["ACCENT"], "middle", "top", bold=True)
    LG.draw(fig, spot, [str(g) for g in _grp], [gcol[g] for g in _grp], reverse=legend_reverse)
    ctx = Ctx(fig, "h", None, None, [], [r["name"] for r in rows])
    ctx.extra.update(dax=dax, geo=geo, row_h=rh, top=top)
    return ctx
